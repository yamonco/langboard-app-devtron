/** Package the SDK panel template; Python's native validator owns the ZIP contract. */
import { cp, lstat, mkdir, mkdtemp, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { delimiter, join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export async function packagePanelTemplate({ declaration, pythonSdk, output, root = process.cwd() }) {
  root = resolve(root);
  const name = JSON.parse(await readFile(join(root, 'package.json'), 'utf8')).name;
  const destination = resolve(root, output || `dist/${name}.zip`);
  const staging = await mkdtemp(join(tmpdir(), 'langboard-app-package-'));
  try {
    if ((await lstat(join(root, 'public'))).isSymbolicLink()) throw new Error('Panel assets must not be symlinks');
    await cp(join(root, 'public'), join(staging, 'panel'), { recursive: true });
    const assets = await readdir(join(staging, 'panel'), { recursive: true, withFileTypes: true });
    if (assets.some(asset => asset.isSymbolicLink())) throw new Error('Panel assets must not be symlinks');
    await mkdir(join(staging, 'panel/sdk'));
    const resolved = spawnSync(process.execPath, ['--input-type=module', '--eval',
      'process.stdout.write(JSON.stringify(["@langboard/app-panel", "@langboard/app-panel/inbox"].map(name => import.meta.resolve(name))))'],
      { cwd: root, encoding: 'utf8', maxBuffer: 16 * 1024 });
    if (resolved.error || resolved.status !== 0) throw new Error('Installed panel SDK exports could not be resolved', { cause: resolved.error });
    const entries = JSON.parse(resolved.stdout);
    for (const [index, name] of ['index.mjs', 'inbox.mjs'].entries()) {
      await cp(fileURLToPath(entries[index]), join(staging, 'panel/sdk', name));
    }
    for (const name of ['panel.mjs', 'inbox.mjs']) {
      const path = join(staging, 'panel', name);
      let source;
      try { source = await readFile(path, 'utf8'); }
      catch (error) { if (error.code === 'ENOENT') continue; throw error; }
      await writeFile(path, source.replaceAll("'/sdk/index.mjs'", "'./sdk/index.mjs'")
        .replaceAll("'@langboard/app-panel/inbox'", "'./sdk/inbox.mjs'"));
    }
    const html = join(staging, 'panel/index.html');
    await writeFile(html, (await readFile(html, 'utf8')).replace(/<script type="importmap">.*?<\/script>/s, '')
      .replace('src="/panel.mjs"', 'src="./panel.mjs"'));
    await writeFile(join(staging, 'panel/config.mjs'), `import {hostOrigin} from './host.mjs';\nexport default {hostOrigin, signalSources: ${JSON.stringify(declaration.signal_sources || [])}};\n`);
    await writeFile(join(staging, 'panel/host.mjs'), 'throw new Error("Install this package on a Langboard host before opening its panel");\n');
    await writeFile(join(staging, 'manifest.json'), JSON.stringify({ package_version: 1, declaration,
      panel_entry: 'panel/index.html', store: { icon: 'panel/icon-light.svg', icon_dark: 'panel/icon-dark.svg', screenshots: [] } }));
    const result = spawnSync(process.env.PYTHON || 'python3', ['-m', 'langboard_sdk.package',
      join(staging, 'manifest.json'), join(staging, 'panel'), destination], {
      cwd: root, encoding: 'utf8', maxBuffer: 256 * 1024,
      env: { ...process.env, PYTHONPATH: [resolve(root, pythonSdk), process.env.PYTHONPATH].filter(Boolean).join(delimiter) },
    });
    if (result.error) throw new Error('Python SDK package build could not start', { cause: result.error });
    if (result.status !== 0) throw new Error('Python SDK rejected the static panel package');
    return destination;
  } finally { await rm(staging, { recursive: true, force: true }); }
}
